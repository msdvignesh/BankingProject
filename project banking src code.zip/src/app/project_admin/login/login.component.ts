import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login.service';
import { Account } from '../Account';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  account: Account = new Account();
  check: boolean = false;

  constructor(private loginService: LoginService, private router: Router) { }

  accountnumber:any;
  password:any;
  ngOnInit(): void {

  }

  getAccount(accountNumber: number, password: string) {

    console.log("getAccount ");
    console.log(accountNumber);
    console.log(password);
    this.loginService.getAccountService(accountNumber, password).subscribe((data: boolean) => {
      this.check = data;
      if (this.check == true) {
        console.log("User id matches");
        sessionStorage.setItem("accountNumber", accountNumber.toString());
        this.router.navigate(['view-account/' + accountNumber]);
        
      }
      else {
        console.log("User id/password is incorrect");

      }
    },
      (err) => {
        console.log(err);
      })
  }

}
