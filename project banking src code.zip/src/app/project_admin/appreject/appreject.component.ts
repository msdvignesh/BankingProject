import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PrjApplicantService } from 'src/app/prj-applicant.service';
import { prjApplicant } from '../admin-home/prjApplicant';

@Component({
  selector: 'app-appreject',
  templateUrl: './appreject.component.html',
  styleUrls: ['./appreject.component.css']
})
export class ApprejectComponent implements OnInit {

  constructor(private applicantserviceObj : PrjApplicantService,private _activatedRoute: ActivatedRoute, private router: Router) { }
  applicant: prjApplicant=new prjApplicant();
  msg:string="";
  selectedId: any;
   anyData: any;

  ngOnInit(): void {

    console.log("adminreject oninit method()...");
    this._activatedRoute.paramMap.subscribe( params=> {
     this.selectedId=params.get('rejectid');
       this.applicantserviceObj.rejectaccount(this.applicant,this.selectedId).subscribe()
  //       (data:prjApplicant[])=> {
  //       this.anyData = data.find(a=> a.applicantId==this.selectedId);
  //      this.applicant = this.anyData;
  // })
});
  }

}
