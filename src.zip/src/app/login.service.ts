import { Injectable } from '@angular/core';
import { Account } from './project_admin/Account';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { parseI18nMeta } from '@angular/compiler/src/render3/view/i18n/meta';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  baseUrl:string = "http://localhost:8080/accounts";
  params:HttpParams = new HttpParams();
  
  constructor(private myHttp:HttpClient) { }

  getAccountService(account:number,password:string):Observable<boolean>{
    console.log("Get method is called");
       return this.myHttp.get<boolean>(this.baseUrl + "/checkUser/"+account+"/"+password);
  }

  viewAccountService(accountNumber:number):Observable<Account>{
    console.log("viewAccountService()");
    return this.myHttp.get<Account>(this.baseUrl+"/viewAccount/"+accountNumber);
  }
}
