import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectedApplicantComponent } from './rejected-applicant.component';

describe('RejectedApplicantComponent', () => {
  let component: RejectedApplicantComponent;
  let fixture: ComponentFixture<RejectedApplicantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RejectedApplicantComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectedApplicantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
