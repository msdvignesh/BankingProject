import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PrjApplicantService } from '../prj-applicant.service';
import { prjApplicant } from '../project_admin/admin-home/prjApplicant';

@Component({
  selector: 'app-rejected-applicant',
  templateUrl: './rejected-applicant.component.html',
  styleUrls: ['./rejected-applicant.component.css']
})
export class RejectedApplicantComponent implements OnInit {
  rejectedApplicantList:prjApplicant[]=[];

  constructor(private appService:PrjApplicantService,private router:Router) { }

  ngOnInit(): void {
  this.getRejectedApplicant();
  }

  getRejectedApplicant(){
    this.appService.viewRejectedApplicantService().subscribe((data:prjApplicant[])=>{
     this.rejectedApplicantList=data;
    },
    (err)=>{
      console.log(err);
    });
    
  }
  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
 
}
