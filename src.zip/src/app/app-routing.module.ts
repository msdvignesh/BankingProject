import { Component, NgModule } from '@angular/core';
import { flush } from '@angular/core/testing';
import { RouterModule, Routes } from '@angular/router';
import { ApprovedApplicantComponent } from './project_admin/approved-applicant/approved-applicant.component';

import { AccountComponent } from './project_admin/account/account.component';
import { AdminApproveComponent } from './project_admin/admin-approve/admin-approve.component';
import { AdminHomeComponent } from './project_admin/admin-home/admin-home.component';
import { AdminLoginComponent } from './project_admin/admin-login/admin-login.component';
import { ApprejectComponent } from './project_admin/appreject/appreject.component';
import { DashboardComponent } from './project_admin/dashboard/dashboard.component';
import { HomePageComponent } from './project_admin/home-page/home-page.component';
import { LoginComponent } from './project_admin/login/login.component';
import { RejectedApplicantComponent } from './rejected-applicant/rejected-applicant.component';
import { SessionExpiredComponent } from './session-expired/session-expired.component';
// import { RegisterComponent } from './register/register.component';
// import { AboutCompanyComponent } from './about-us/about-company/about-company.component';
// import { AboutEmployeesComponent } from './about-us/about-employees/about-employees.component';
// import { AboutUsComponent } from './about-us/about-us.component';
// import { ContactUsComponent } from './contact-us/contact-us.component';
// import { DashboardComponent } from './dashboard/dashboard.component';
// import { LoginComponent } from './login/login.component';
// import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
{path:'',component:HomePageComponent},
{path:'adminapprove/:id',component:AdminApproveComponent},
{path:'accountcreation/:appid',component:AccountComponent},
{path:'applicantreject/:rejectid',component:ApprejectComponent},
{path:'adminhome',
  children:[
    {path:'',component:AdminHomeComponent},
    {path:'rejected-applicant',component:RejectedApplicantComponent},
    {path:'approved-applicant',component:ApprovedApplicantComponent}
  ]},
{path:'view-account/:accountNumber',component:DashboardComponent},
{path:'admin-login',component:AdminLoginComponent},
{path:'user-home',component:LoginComponent},

{path:'session-expired',component:SessionExpiredComponent},



// {path:'contactus',component:ContactUsComponent},
// {path:'**',component:PageNotFoundComponent},
//  {path:'',redirectTo:'/contactus' , pathMatch:'full'},
// {path:'login',component:LoginComponent},
// {path:'dashboard',component:DashboardComponent},
// {path:'register',component:RegisterComponent},
// {path:'register',component:RegisterComponent},
// {path:'aboutus',
//     children: [
//       {path:'',component:AboutUsComponent},
//       {path:'about-emp', component: AboutEmployeesComponent},
//       {path:'about-cmp', component: AboutCompanyComponent},
//     ]
// },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }