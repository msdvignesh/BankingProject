import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PrjApplicantService } from 'src/app/prj-applicant.service';
import { prjApplicant } from '../admin-home/prjApplicant';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  constructor(private applicantserviceObj : PrjApplicantService , private _activatedRoute: ActivatedRoute, private router: Router) 
  { }
    applicant:prjApplicant= new prjApplicant();
    msg:string="";
    selectedId: any;
   anyData: any;
  ngOnInit(): void {

    console.log("account creation ngOninit maethod()...");
    this._activatedRoute.paramMap.subscribe( params=> {
     this.selectedId=params.get('appid');
    
    this.applicantserviceObj.addaccount(this.applicant,this.selectedId).subscribe(
    (data:any) =>
    {
      this.msg= data;
      console.log(data);
      console.log(this.msg);
    },
    (err) =>
    {
      console.log(err);
    })
  });
  }
  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
 
}
  


