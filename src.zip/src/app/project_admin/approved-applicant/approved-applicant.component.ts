import { Component, OnInit } from '@angular/core';
import { RouteConfigLoadEnd, Router } from '@angular/router';
import { PrjApplicantService } from '../../prj-applicant.service';
import { prjApplicant } from '../admin-home/prjApplicant';

@Component({
  selector: 'app-approved-applicant',
  templateUrl: './approved-applicant.component.html',
  styleUrls: ['./approved-applicant.component.css']
})
export class ApprovedApplicantComponent implements OnInit {
  approvedApplicantList:prjApplicant[]=[];

  constructor(private appService:PrjApplicantService,private router:Router) { }

  ngOnInit(): void {
  this.getApprovedApplicant();
  }

  getApprovedApplicant(){
    this.appService.viewApprovedApplicantService().subscribe((data:prjApplicant[])=>{
      this.approvedApplicantList=data;
    },
    err=>{

    });
  }
  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
 
}
