import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PrjApplicantService } from 'src/app/prj-applicant.service';
import { AdminApproveComponent } from '../admin-approve/admin-approve.component';
import { prjApplicant } from './prjApplicant';



@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {


  applicantArray : prjApplicant[]=[];

  constructor(private applicantserviceObj : PrjApplicantService,private router:Router) { }
 
  ngOnInit(): void {
   this.showPendingApplication();
  }

  showPendingApplication()
  {
    console.log("showPendingApplication() method")
    this.applicantserviceObj.loadAllPendingapplicantsService().subscribe(
      (data:prjApplicant[]) =>
      {
        this.applicantArray=data;
      },
      (err) =>
      {
        console.log(err);
      }

    )
  }
  viewapplicant(appid : number)
  {
    console.log("viewapplicant() method")
    this.applicantserviceObj.viewsingleapplicant(appid);
  
  }
  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
 
  

 
}
