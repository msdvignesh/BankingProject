import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  username:string="";
  password:string="";
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  checkAdmin(){
    if((this.username="admin")&&(this.password=="admin")){
      sessionStorage.setItem("admin",this.username);
      this.router.navigate(['/adminhome']);
    }
    else{
      this.router.navigate(['/admin-login']);
    }
  }

}
