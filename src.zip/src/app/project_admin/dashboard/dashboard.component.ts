import { PlatformLocation } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from 'src/app/login.service';
import { HostListener } from '@angular/core';

import { Account } from '../Account';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  account:Account=new Account();
  selectedId:any;
  anyData:any;
  event:any;
  constructor(private login:LoginService,private router:Router, private _activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
   this.selectedId=this._activatedRoute.snapshot.paramMap.get("accountNumber");
   this.viewAccount(this.selectedId);
   this.anyData = this.getSession();
    
       }

  viewAccount(accountnumber:number){
    this.login.viewAccountService(accountnumber).subscribe((data:Account)=>{
      this.account =data;
  },
  (err)=>{
    console.log(err);
  })

  }
  getSession(){
    return sessionStorage.getItem('accountNumber');
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
 
}
