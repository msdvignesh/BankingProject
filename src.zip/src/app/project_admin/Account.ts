
export class Account {
	accountnumber:number =0;
	password:string="";
	currentBalance:number=0;
	
}
